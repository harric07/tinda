# tinda
#### Buggy Sub-Alpha stage, Please Check back later, thankyou.
 
## Modern wrapper for basic things. 

### Installation:

```
pip install tinda

```

## Usage:

```
from tinda import XXX   


assistant = XXX()

assistant.say('string of whatever')

assistant.image(query) #google image search of the query string

# the same works for Google, Github, Stackoverflow, Youtube, etc.
assistant.google(query)
assistant.stackoverflow(query) 

assitant.getIp() # returns private and public ip

assiatnt.getLocation() # returns location data

assistant.time() 
assistant.date()

assistant.speedtest() #returns internet speed test results


# full list comming soon.


```


Developed by:
Harpreet Singh © 2021
