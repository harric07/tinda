# tinda
#### Buggy Sub-Alpha stage, Please Check back later, thankyou.
 
## Modern wrapper for basic things. 

### Installation:

```

# to install it from pypi

pip install tinda
# or
pip3 install tinda

```

## Usage:

```
import * from tinda     # to import everything
import XXX from tinda     # to import an object

def show_desktop(): 
    i = XXX()
    i.showDesktop() # this will call the show desktop function

def listen():
    x = XXX()
    x.listen() # this will call the listen function and display the string in console.



```


Developed by:
Harpreet Singh © 2021
