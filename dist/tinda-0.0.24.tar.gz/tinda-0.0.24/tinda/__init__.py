from tinda.functions import *
from tinda.bot import *
from tinda.sock import *
from tinda.tercli import tercli
from tinda.terser import terser
